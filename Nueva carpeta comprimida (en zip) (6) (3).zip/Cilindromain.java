package com.mycompany.cilindromain;

import javax.swing.JOptionPane;

/**
 * La clase representa un cilindro con un radio y una altura.
 * Proporciona métodos para calcular el área y el volumen del cilindro.
 */
public class Cilindromain {
    private double radio;
    private double altura;

    /**
     * Constructor de la clase Cilindro
     * 
     *
     * @param radio el radio del cilindro
     * @param altura la altura del cilindro
     */
    public Cilindromain(double radio, double altura) {
        this.radio = radio;
        this.altura = altura;
    }

    /**
     * Obtiene el radio del cilindro.
     *
     * @return el radio del cilindro
     */
    public double getRadio() {
        return radio;
    }

    /**
     * Establece el radio del cilindro.
     *
     * @param radio el nuevo radio del cilindro
     */
    public void setRadio(double radio) {
        this.radio = radio;
    }

    /**
     * Obtiene la altura del cilindro.
     *
     * @return la altura del cilindro
     */
    public double getAltura() {
        return altura;
    }

    /**
     * Establece la altura del cilindro.
     *
     * @param altura la nueva altura del cilindro
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }

    /**
     * Calcula el área superficial del cilindro.
     * @return el área superficial del cilindro
     */
    public double calcularArea() {
        return 2 * Math.PI * radio * altura + 2 * Math.PI * radio * radio;
    }

    /**
     * Calcula el volumen del cilindro.
     *
     * @return el volumen del cilindro
     */
    public double calcularVolumen() {
        return Math.PI * radio * radio * altura;
    }

    /**
     * Solicita al usuario que ingrese el radio y la altura del cilindro y crea
     * una nueva instancia de {@code CilindroJava} con esos valores.
     *
     * @return una nueva instancia de {@code CilindroJava}
     */
    public static Cilindromain crearCilindro() {
        double radio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el radio del cilindro:"));
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura del cilindro:"));
        return new Cilindromain(radio, altura);
    }

    /**
     * Método principal que crea tres cilindros, imprime su volumen y área, y
     * determina cuál de los tres cilindros tiene el menor volumen.
     *
     * @param args argumentos de línea de comandos (no se utilizan)
     */
    public static void main(String[] args) {
        // Creamos tres cilindros
        Cilindromain cilindro1 = crearCilindro();
        Cilindromain cilindro2 = crearCilindro();
        Cilindromain cilindro3 = crearCilindro();

        // Imprimimos el volumen y área de cada cilindro
        System.out.println("Cilindro 1: Volumen=" + cilindro1.calcularVolumen() + ", Área=" + cilindro1.calcularArea());
        System.out.println("Cilindro 2: Volumen=" + cilindro2.calcularVolumen() + ", Área=" + cilindro2.calcularArea());
        System.out.println("Cilindro 3: Volumen=" + cilindro3.calcularVolumen() + ", Área=" + cilindro3.calcularArea());

        // Comparamos los cilindros y mostramos el menor
        if (cilindro1.calcularVolumen() <= cilindro2.calcularVolumen() && cilindro1.calcularVolumen() <= cilindro3.calcularVolumen()) {
            System.out.println("El cilindro 1 es el menor");
        } else if (cilindro2.calcularVolumen() <= cilindro3.calcularVolumen()) {
            System.out.println("El cilindro 2 es el menor");
        } else {
            System.out.println("El cilindro 3 es el menor");
        }
    }
}
