package com.mycompany.bisiestorango;

/**
 *
 * @author Nirmin
 */

import java.util.Scanner;

/**
 * Esta clase permite calcular e imprimir los años bisiestos que haya entre dos valores ingresados por el usuario.
 */
public class BisiestoRango {

    /**
     * Método principal que llama a los diferentes métodos creados.
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int inicio = ingresarAnio(scanner, "Introduce el primer año: ");
        int fin = ingresarAnio(scanner, "Introduce el segundo año: ");
        int numBisiestos = calcularBisiestos(inicio, fin);
        mostrarResultado(inicio, fin, numBisiestos);
    }

    /**
     * Este método determina si un año es bisiesto o no.
     * @param anio Año que se quiere comprobar si es bisiesto.
     * @return Verdadero si el año es bisiesto, falso en caso contrario.
     */
    public static boolean esBisiesto(int anio) {
        return (anio % 4 == 0 && anio % 100 != 0) || (anio % 100 == 0 && anio % 400 == 0);
    }

    /**
     * Este método solicita al usuario que ingrese un año y lo devuelve.
     * @param scanner Scanner utilizado para la entrada de datos.
     * @param mensaje Mensaje a mostrar al usuario antes de solicitar el año.
     * @return El año ingresado por el usuario.
     */
    public static int ingresarAnio(Scanner scanner, String mensaje) {
        System.out.println(mensaje);
        return scanner.nextInt();
    }

    /**
     * Este método calcula el número de años bisiestos en un rango.
     * @param inicio El año de inicio del rango.
     * @param fin El año de fin del rango.
     * @return El número de años bisiestos encontrados.
     */
    public static int calcularBisiestos(int inicio, int fin) {
        int numBisiestos = 0;
        for (int anioActual = inicio; anioActual <= fin; anioActual++) {
            if (esBisiesto(anioActual)) {
                System.out.println("El año -> " + anioActual + " es bisiesto");
                numBisiestos++;
            }
        }
        return numBisiestos;
    }

    /**
     * Este método muestra por pantalla el número de años bisiestos encontrados en un rango.
     * @param inicio El año de inicio del rango.
     * @param fin El año de fin del rango.
     * @param numBisiestos El número de años bisiestos encontrados.
     */
    public static void mostrarResultado(int inicio, int fin, int numBisiestos) {
        if (numBisiestos > 0) {
            System.out.println("El número de años bisiestos entre los años -> " + inicio + " y -> " + fin);
            System.out.println("Es -> " + numBisiestos);
        } else {
            System.out.println("No hemos encontrado número bisiestos en el rango solicitado.");
        }
    }
}
